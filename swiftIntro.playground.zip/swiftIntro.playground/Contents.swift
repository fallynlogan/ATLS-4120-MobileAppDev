import UIKit

var str = "Hello, playground"
var message : String = "Hellow World"
let classMax : Int = 20
var age: Int
age = 21

var name = "Fallyn"
print("Hello World")
print("hi " + name)
print("hi \(name)")

let a = 42
let b = 0.0492
let c = Double(a) + b

//tuples
let violet = ("#EE82EE", 238, 130, 238)
print("Violet is \(violet.0)")
let (hex, red, green, blue) = violet
print("Violet is \(hex)")

// a..b closed range (range that includes a and b)
// a..<b (includes a but not b)
// ...b one sided
// a.. one sided other way

//conditionals
var young = "you're young"
var notyoung = "you're not young"
if age < 21 {
 print(young)
} else {
    print(notyoung)
}
age < 21 ? young : notyoung

//switch statements
switch age{
    case 0...5: print("you're a tiny guy")
    case 6..<21: print("enjoy school")
    case 21...55: print("welcome to the real world")
default: print("i dont know what you're doing")
}

//loops
for count in 0...age {
    print("my count is \(count)")
}

//functions
func sayHi(){
    print("Hi")
}
sayHi()

func sayHello(first: String, last: String){
    print("hi \(first) \(last)")
}
sayHello(first: "Fallyn", last: "Logan")

func sayWhat(firstName first: String, lastName last: String){
    print("what \(first) \(last)?")
}
sayWhat(firstName: "Melissa", lastName: "Lapinski")

func sayWhere(_ place: String){
    print(place)
}
sayWhere("Pittsburgh")

func sayWho(firstName: String, lastName: String) -> String {
    return "who " + firstName + " " + lastName + "?"
}
let msg2 = sayWho(firstName: "Vada" , lastName: "Lapinski")
print(msg2)

//optionals
var score : Int?
//score = 80
//print("Score is \(score)")
if score != nil {
    print("Score is \(score!)")
}

if let currentScore = score {
    print("My current score is \(currentScore)")
}
